#!/system/bin/sh

# 模块路径
MODDIR=/data/adb/modules/Tricky_Store-xiaoyi

# 提示配置信息
echo "📁 模块配置文件路径："
echo "   - 模式配置: $MODDIR/conf/mode.conf"
echo "   - tee 设置: $MODDIR/conf/tee.conf"
echo "   - cron 设置: $MODDIR/cron/root"
echo ""
echo "📝 你可以通过手动编辑上述文件来自定义模块模式，此模块为非UI模块，你只能通过手动修改配置文件修改运行模式。或者你可以通过后续更新WEBUI版模块来更新你的配置"
echo ""

# 执行主脚本
YIZDOG=$MODDIR/xiaoyi/yizdog.sh
if [ -f "$YIZDOG" ]; then
    echo "🚀 正在执行 yizdog.sh..."
    sh "$YIZDOG"
    echo "✅ yizdog.sh 执行完成。"
else
    echo "❌ 未找到主脚本: $YIZDOG"
fi
