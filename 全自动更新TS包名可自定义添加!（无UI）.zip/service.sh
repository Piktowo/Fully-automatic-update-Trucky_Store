#!/system/bin/sh
MODDIR=${0%/*}

(
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done

export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"

# 启动定时任务
crond -c "$MODDIR/cron"

# 确保 log 目录存在
LOGDIR="$MODDIR/log"
NOW=$(date "+%Y%m%d_%H%M%S")
if [ ! -d "$LOGDIR" ]; then
    mkdir -p "$LOGDIR"
    LOGFILE="$LOGDIR/new_$NOW.log"
else
    LOGFILE="$LOGDIR/$NOW.log"
fi

# 写入 tee_status 内容（如果存在）
TEE_STATUS_FILE="/data/adb/tricky_store/tee_status"
[ -f "$TEE_STATUS_FILE" ] && cat "$TEE_STATUS_FILE" > "$LOGFILE"

# 设置权限
chmod -R 777 "$MODDIR"
) &